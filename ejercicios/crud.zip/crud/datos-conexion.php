<?php
$servidor="localhost";
$usuario="root";
$clave="";
$baseDatos="crud";
$puerto=3306;
?>