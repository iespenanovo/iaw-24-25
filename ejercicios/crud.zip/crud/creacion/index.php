<?php 
// el silencio es oro
 ?>